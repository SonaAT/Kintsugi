// Logout function
function logout() {
    // Redirect to login page
    window.location.href = "login.html";
}
